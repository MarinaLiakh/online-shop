import React from "react";

export const Contacts = () => {
  return (
    <div>
      <h2>Contacts</h2>
      <div>
        Adress: <span>Gomel</span>
      </div>
      <div>
        Telephone: <span>+375 44 1234567</span>
      </div>
    </div>
  );
};
