import React from "react";
import styles from "./index.module.css";

export const SearchProductInput = () => {
  return <input type="text" className={styles.searchInput} />;
};
