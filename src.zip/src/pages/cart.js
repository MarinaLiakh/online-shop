import React from "react";

export const Cart = () => {
  return (
    <div>
      <h2>Cart</h2>
      <ul>
        <li>Cart item</li>
      </ul>
      <button>Purchase</button>
    </div>
  );
};
