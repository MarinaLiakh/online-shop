import React from "react";

export const Login = () => {
  return (
    <div>
      <h2>Login</h2>
      <div>
        <input type="text" />
      </div>
      <div>
        <input type="password" />
      </div>
      <button>Login</button>
    </div>
  );
};
